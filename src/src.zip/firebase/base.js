import firebase from "firebase";

//SMRT
const app = firebase.initializeApp({
    apiKey: "AIzaSyCTZR2xpIvgwuxfxOhxPP2bk9XwvRJENu8",
    authDomain: "smrt-b5bb9.firebaseapp.com",
    databaseURL: "https://smrt-b5bb9-default-rtdb.firebaseio.com",
    projectId: "smrt-b5bb9",
    storageBucket: "smrt-b5bb9.appspot.com",
    messagingSenderId: "193029185355",
    appId: "1:193029185355:web:75eafb16aa4e41a34712ce"
});

export default app;